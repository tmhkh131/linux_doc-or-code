#include "lib/lib.h"
#include "lib/lib1.h"

int main(void)
{
    print();
    print1();
}