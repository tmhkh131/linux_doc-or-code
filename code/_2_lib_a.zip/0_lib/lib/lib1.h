#ifndef _LIB1_H
#define _LIB1_H

#include "stdint.h"

void print1(void);

#endif
