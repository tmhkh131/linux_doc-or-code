#ifndef _LIB_H
#define _LIB_H

#include "stdint.h"

void print(void);

#endif
