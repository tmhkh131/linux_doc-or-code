#include "lib.h"
#include "stdio.h"

void print1()
{
    printf("\r\nlib1test\r\n");
}