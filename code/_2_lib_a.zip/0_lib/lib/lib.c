#include "lib.h"
#include "stdio.h"

void print()
{
    printf("\r\nlibtest\r\n");
}